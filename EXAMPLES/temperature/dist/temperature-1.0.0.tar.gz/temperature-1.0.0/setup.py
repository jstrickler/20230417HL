from setuptools import setup

# note -- this file is not used when buildng with pyproject.toml

if __name__ == "__main__":
    setup()

